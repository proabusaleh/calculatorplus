import 'dart:convert';

import 'package:http/http.dart' as http;

import 'app_info.dart';

/// Result of a GitHub release update check.
class UpdateInfo {
  final String latestVersion;
  final String releaseNotes;
  final String? apkUrl;
  final String releaseUrl;
  final bool hasUpdate;

  const UpdateInfo({
    required this.latestVersion,
    required this.releaseNotes,
    this.apkUrl,
    required this.releaseUrl,
    required this.hasUpdate,
  });
}

/// Checks for app updates by querying the GitHub releases API.
class UpdateService {
  UpdateService._();

  /// GitHub owner and repository that hosts the releases.
  static const String _owner = 'proabusaleh';
  static const String _repo = 'calculatorplus';
  static const Duration _timeout = Duration(seconds: 12);

  static String get repoUrl => 'https://github.com/$_owner/$_repo';

  /// Fetches the latest stable GitHub release and compares it with the app.
  ///
  /// Network/API failures intentionally return a result with no update so the
  /// update prompt never interrupts normal calculator use.
  static Future<UpdateInfo> checkForUpdate() => _fetchLatestRelease();

  static Future<UpdateInfo> _fetchLatestRelease() async {
    final uri = Uri.parse(
      'https://api.github.com/repos/$_owner/$_repo/releases/latest',
    );

    try {
      final response = await http.get(
        uri,
        headers: {
          'Accept': 'application/vnd.github+json',
          'User-Agent': 'HikmahCalculator/${AppInfo.version}',
        },
      ).timeout(_timeout);

      if (response.statusCode != 200) return _noUpdate();

      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return _noUpdate();

      final tagName = (decoded['tag_name'] as String? ?? '').trim();
      final latestVersion = normalizeVersion(tagName);
      final releaseNotes = (decoded['body'] as String? ?? '').trim();
      final rawReleaseUrl = decoded['html_url'] as String?;
      final releaseUrl = _isHttpUrl(rawReleaseUrl) ? rawReleaseUrl! : repoUrl;

      // Find the first valid APK asset. Ignore malformed or non-HTTPS URLs.
      String? apkUrl;
      final assets = decoded['assets'];
      if (assets is List) {
        for (final asset in assets) {
          if (asset is! Map<String, dynamic>) continue;
          final name = (asset['name'] as String? ?? '').toLowerCase();
          final candidate = asset['browser_download_url'] as String?;
          if (name.endsWith('.apk') && _isHttpsUrl(candidate)) {
            apkUrl = candidate;
            break;
          }
        }
      }

      final currentVersion = normalizeVersion(AppInfo.version);
      final hasUpdate = _isValidVersion(latestVersion) &&
          _isValidVersion(currentVersion) &&
          _compareVersions(latestVersion, currentVersion) > 0;

      return UpdateInfo(
        latestVersion: latestVersion,
        releaseNotes: releaseNotes,
        apkUrl: apkUrl,
        releaseUrl: releaseUrl,
        hasUpdate: hasUpdate,
      );
    } catch (_) {
      return _noUpdate();
    }
  }

  /// Accept HTTPS destinations only, including the release-page fallback.
  /// The updater must not open an unencrypted URL from remote API data.
  static bool _isHttpUrl(String? value) => _isHttpsUrl(value);

  static bool _isHttpsUrl(String? value) {
    if (value == null || value.isEmpty) return false;
    final uri = Uri.tryParse(value);
    return uri != null && uri.scheme == 'https' && uri.host.isNotEmpty;
  }

  static UpdateInfo _noUpdate() => const UpdateInfo(
        latestVersion: '',
        releaseNotes: '',
        apkUrl: null,
        releaseUrl: '',
        hasUpdate: false,
      );

  /// Normalizes a semantic version by removing a leading `v` and build
  /// metadata. Pre-release identifiers are preserved because they affect
  /// semantic-version precedence (for example, 2.0.0-beta is older than 2.0.0).
  static String normalizeVersion(String raw) {
    var version = raw.trim().replaceFirst(RegExp(r'^[vV]'), '');
    final plus = version.indexOf('+');
    if (plus >= 0) version = version.substring(0, plus);
    return version.trim();
  }

  /// Compares semantic versions. Returns positive when [a] is newer, zero
  /// when equal, and negative when older. Build metadata is ignored.
  static int compareVersions(String a, String b) =>
      _compareVersions(normalizeVersion(a), normalizeVersion(b));

  static bool _isValidVersion(String version) => RegExp(
        r'^\d+(?:\.\d+)*(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$',
      ).hasMatch(version);

  static int _compareVersions(String a, String b) {
    if (!_isValidVersion(a) || !_isValidVersion(b)) return 0;

    final aDash = a.indexOf('-');
    final bDash = b.indexOf('-');
    final aCoreText = aDash < 0 ? a : a.substring(0, aDash);
    final bCoreText = bDash < 0 ? b : b.substring(0, bDash);
    final aCore = aCoreText.split('.').map(int.parse).toList();
    final bCore = bCoreText.split('.').map(int.parse).toList();
    final coreLength = aCore.length > bCore.length ? aCore.length : bCore.length;

    for (var i = 0; i < coreLength; i++) {
      final av = i < aCore.length ? aCore[i] : 0;
      final bv = i < bCore.length ? bCore[i] : 0;
      if (av != bv) return av.compareTo(bv);
    }

    // A stable version takes precedence over its pre-release version.
    final aIsPreRelease = aDash >= 0;
    final bIsPreRelease = bDash >= 0;
    if (!aIsPreRelease && !bIsPreRelease) return 0;
    if (!aIsPreRelease) return 1;
    if (!bIsPreRelease) return -1;

    final aIds = a.substring(aDash + 1).split('.');
    final bIds = b.substring(bDash + 1).split('.');
    final idLength = aIds.length > bIds.length ? aIds.length : bIds.length;
    for (var i = 0; i < idLength; i++) {
      if (i >= aIds.length) return -1;
      if (i >= bIds.length) return 1;
      final av = aIds[i];
      final bv = bIds[i];
      if (av == bv) continue;

      final aNumeric = RegExp(r'^\d+$').hasMatch(av);
      final bNumeric = RegExp(r'^\d+$').hasMatch(bv);
      if (aNumeric && bNumeric) {
        final comparison = int.parse(av).compareTo(int.parse(bv));
        if (comparison != 0) return comparison;
      } else if (aNumeric != bNumeric) {
        return aNumeric ? -1 : 1;
      } else {
        final comparison = av.compareTo(bv);
        if (comparison != 0) return comparison;
      }
    }
    return 0;
  }
}
