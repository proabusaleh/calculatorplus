import 'package:shared_preferences/shared_preferences.dart';

class PrefsService {
  static SharedPreferences? _instance;

  static Future<SharedPreferences> getInstance() async {
    _instance ??= await SharedPreferences.getInstance();
    return _instance!;
  }

  /// Clears the cached instance for deterministic tests after setting mock data.
  static void resetInstanceForTesting() {
    _instance = null;
  }
}
