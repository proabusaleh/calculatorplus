# Phase 4 — Security & Performance Audit

## Changes applied

- **Release signing fails closed.** A release build now requires `android/key.properties` unless the developer explicitly opts into a debug-signed smoke build using `-PallowDebugReleaseSigning=true`.
- **CI and publishing are separated.** The general CI workflow opts into debug signing only to verify compilation. The tag-triggered release workflow requires a production keystore provided through GitHub Actions secrets.
- **Release signing secrets are not committed.** Configure `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`, and `ANDROID_STORE_PASSWORD` in repository Actions secrets. Keep the keystore and `android/key.properties` out of version control.
- **Update URLs are HTTPS-only.** Release-page URLs received from the GitHub API are no longer accepted over plain HTTP. APK URLs were already required to use HTTPS.

## Required owner actions

1. Create a dedicated Android upload/release keystore and securely back it up.
2. Add the four Actions secrets listed above before creating a `v*` release tag. The workflow writes the keystore to `android/app/release-key.jks` and ignores it from version control.
3. Confirm the GitHub repository and package identifier are the intended production targets.
4. Review dependency updates and test on a low-memory device and the minimum supported Android API level.
5. Run `flutter pub get`, `flutter analyze`, `flutter test`, and a signed `flutter build apk --release` in a Flutter SDK environment.

## Verification limits

Flutter/Dart are not available in the packaging environment, so Flutter tests and an Android build were not executed here. Archive integrity and static workflow/configuration checks should not be interpreted as proof of a successful build or a complete penetration test.
