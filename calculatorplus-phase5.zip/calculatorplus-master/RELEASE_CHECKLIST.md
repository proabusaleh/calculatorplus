# Hikmah Calculator Plus — Final Release Checklist (Phase 5)

This checklist is the release gate for production APKs. A source ZIP or successful static inspection is not proof that a Flutter build or device test passed.

## Before creating a release tag

- [ ] Run `flutter doctor -v` and resolve Android toolchain issues.
- [ ] Run `flutter pub get`.
- [ ] Run `dart format --output=none --set-exit-if-changed lib test` and fix any reported formatting issues.
- [ ] Run `flutter analyze` and resolve errors and actionable warnings.
- [ ] Run `flutter test` and confirm all tests pass.
- [ ] Run `flutter build apk --release` with a production keystore configured.
- [ ] Install the APK on a supported Android device and smoke-test startup, basic/scientific calculations, history, settings/theme, and update-check failure handling.
- [ ] Check a low-memory device and the minimum supported Android version (API 26).
- [ ] Confirm `version:` in `pubspec.yaml` matches the intended release tag, excluding the `v` prefix and build suffix. Example: `2.0.5+6` → tag `v2.0.5`.

## GitHub Actions production signing

Configure these repository Actions secrets before pushing a release tag:

- `ANDROID_KEYSTORE_BASE64`: base64-encoded production keystore file.
- `ANDROID_KEY_ALIAS`: key alias in the keystore.
- `ANDROID_KEY_PASSWORD`: private-key password.
- `ANDROID_STORE_PASSWORD`: keystore password.

Never commit the keystore, `android/key.properties`, or any signing passwords. Back up the keystore securely: losing it can prevent updates to an already published Android application with the same application ID.

## Release workflow behavior

The tag-triggered workflow now:

1. Verifies the tag matches the app version in `pubspec.yaml`.
2. Requires all production signing secrets.
3. Runs dependency installation, Flutter analysis, tests, and a signed release build.
4. Verifies the APK signature using Android `apksigner`.
5. Publishes the APK and a SHA-256 checksum file to the GitHub Release.

A checksum helps detect accidental or in-transit file changes; it does not independently prove that an APK is trustworthy. Verify the release signer certificate fingerprint against a trusted value maintained by the project owner.

## Device smoke test

- [ ] Install/update succeeds and app launches.
- [ ] `2 + 2` returns `4`; test parentheses and operator precedence.
- [ ] Scientific mode respects selected angle units.
- [ ] Division by zero and invalid domains show a safe error/result.
- [ ] History persists across app restart and can be cleared.
- [ ] Theme and preferences persist across app restart.
- [ ] Offline update check shows a recoverable error rather than claiming “up to date.”
- [ ] No crash when navigating rapidly between screens or reopening after backgrounding.

## Validation status for this ZIP

The workflow and checklist have been updated by source inspection. Flutter/Dart and a real Android device were not available in the packaging environment, so `flutter analyze`, `flutter test`, APK build, signature verification, and device smoke tests remain **not run** until CI or a local Flutter environment executes them.
