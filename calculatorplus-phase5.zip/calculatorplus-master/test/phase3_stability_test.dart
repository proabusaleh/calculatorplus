import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hikmah_calculator/models/display_preferences.dart';
import 'package:hikmah_calculator/providers/calculator_provider.dart';
import 'package:hikmah_calculator/services/prefs_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Phase 3 persisted-data stability', () {
    test('display preferences recover from invalid enum and size values', () {
      final preferences = DisplayPreferences.fromJson({
        'format': 999,
        'decimalSeparator': -1,
        'angleDisplay': 99,
        'displayFontSize': 1000,
        'resultFontSize': -20,
        'fontFamily': '  ',
        'maxDecimalPlaces': 999,
      });

      expect(preferences.format, DisplayFormat.standard);
      expect(preferences.decimalSeparator, DecimalSeparator.dot);
      expect(preferences.angleDisplay, AngleDisplayUnit.degrees);
      expect(preferences.displayFontSize, 1.8);
      expect(preferences.resultFontSize, 0.7);
      expect(preferences.fontFamily, 'Inter');
      expect(preferences.maxDecimalPlaces, 15);
    });

    test('history loader skips malformed entries and notifies listeners', () async {
      final valid = jsonEncode({
        'expression': '2+2',
        'result': '4',
        'timestamp': DateTime(2026, 1, 1).toIso8601String(),
        'isScientific': false,
        'isBookmarked': false,
      });
      SharedPreferences.setMockInitialValues({
        'calc_history_v2': ['not-json', valid, '{"expression": 1}'],
      });
      PrefsService.resetInstanceForTesting();

      final provider = CalculatorProvider();
      var notified = false;
      provider.addListener(() => notified = true);
      await Future<void>.delayed(const Duration(milliseconds: 50));

      expect(provider.history, hasLength(1));
      expect(provider.history.single.expression, '2+2');
      expect(notified, isTrue);
      provider.dispose();
    });
  });
}
