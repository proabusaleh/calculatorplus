import 'package:flutter_test/flutter_test.dart';
import 'package:hikmah_calculator/services/calculator_service.dart';
import 'package:hikmah_calculator/services/financial_service.dart';
import 'package:hikmah_calculator/services/statistics_service.dart';

void main() {
  group('CalculatorService regression tests', () {
    test('evaluates arithmetic with operator precedence', () {
      final result = CalculatorService.evaluate('2+3*4');
      expect(result.isError, isFalse);
      expect(result.value, '14');
    });

    test('reports division by zero as an error', () {
      final result = CalculatorService.evaluate('1/0');
      expect(result.isError, isTrue);
    });

    test('reports invalid square-root domain as an error', () {
      final result = CalculatorService.evaluate('sqrt(-1)');
      expect(result.isError, isTrue);
    });
  });

  group('StatisticsService regression tests', () {
    test('calculates mean, median, and population variance', () {
      expect(StatisticsService.mean([1, 2, 3, 4]), 2.5);
      expect(StatisticsService.median([4, 1, 3, 2]), 2.5);
      expect(StatisticsService.variance([1, 2, 3]), closeTo(2 / 3, 1e-12));
    });

    test('empty product is the multiplicative identity', () {
      expect(StatisticsService.product([]), 1);
    });

    test('Poisson distribution handles zero rate correctly', () {
      expect(StatisticsService.poissonPMF(0, 0), 1);
      expect(StatisticsService.poissonPMF(1, 0), 0);
      expect(StatisticsService.poissonCDF(0, 0), 1);
    });

    test('linear regression recovers a simple line', () {
      final result = StatisticsService.linearRegression([1, 2, 3], [3, 5, 7]);
      expect(result.slope, closeTo(2, 1e-12));
      expect(result.intercept, closeTo(1, 1e-12));
      expect(result.r, closeTo(1, 1e-12));
    });
  });

  group('FinancialService regression tests', () {
    test('calculates future value with annual compounding', () {
      expect(FinancialService.futureValue(100, 0.1, 2), closeTo(121, 1e-12));
    });

    test('calculates a zero-interest loan payment', () {
      expect(FinancialService.monthlyPayment(1200, 0, 12), closeTo(100, 1e-12));
    });

    test('rejects a zero-month loan instead of dividing by zero', () {
      expect(FinancialService.monthlyPayment(1200, 0.05, 0).isNaN, isTrue);
      expect(FinancialService.totalInterest(1200, 0.05, 0).isNaN, isTrue);
      expect(FinancialService.amortizationSchedule(1200, 0.05, 0), isEmpty);
    });

    test('rejects invalid compounding frequency', () {
      expect(FinancialService.futureValue(100, 0.05, 2, compoundsPerYear: 0).isNaN, isTrue);
    });
  });
}
