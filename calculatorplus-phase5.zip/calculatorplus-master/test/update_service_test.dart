import 'package:flutter_test/flutter_test.dart';

import 'package:hikmah_calculator/services/update_service.dart';

void main() {
  group('normalizeVersion', () {
    test('strips a leading v', () {
      expect(UpdateService.normalizeVersion('v2.0.3'), '2.0.3');
    });

    test('strips build metadata', () {
      expect(UpdateService.normalizeVersion('v2.0.3+4'), '2.0.3');
      expect(UpdateService.normalizeVersion('2.0.3+4'), '2.0.3');
    });

    test('preserves prerelease identifiers', () {
      expect(UpdateService.normalizeVersion('v2.0.3-beta.1'), '2.0.3-beta.1');
    });

    test('trims whitespace and leaves empty input empty', () {
      expect(UpdateService.normalizeVersion('  2.0.3  '), '2.0.3');
      expect(UpdateService.normalizeVersion(''), isEmpty);
    });
  });

  group('compareVersions', () {
    test('compares numeric version components', () {
      expect(UpdateService.compareVersions('2.0.3', '2.0.2'), greaterThan(0));
      expect(UpdateService.compareVersions('2.0.2', '2.0.10'), lessThan(0));
      expect(UpdateService.compareVersions('2.0.10', '2.0.3'), greaterThan(0));
    });

    test('treats missing trailing zero components as equal', () {
      expect(UpdateService.compareVersions('2.0', '2.0.0'), 0);
    });

    test('ignores build metadata', () {
      expect(UpdateService.compareVersions('v2.0.3+4', '2.0.3'), 0);
    });

    test('stable version is newer than prerelease', () {
      expect(UpdateService.compareVersions('2.0.3', '2.0.3-beta.1'), greaterThan(0));
      expect(UpdateService.compareVersions('2.0.3-beta.1', '2.0.3'), lessThan(0));
    });

    test('compares prerelease identifiers by semantic version rules', () {
      expect(UpdateService.compareVersions('2.0.3-alpha', '2.0.3-beta'), lessThan(0));
      expect(UpdateService.compareVersions('2.0.3-beta.2', '2.0.3-beta.11'), lessThan(0));
      expect(UpdateService.compareVersions('2.0.3-beta.1', '2.0.3-beta.1'), 0);
      expect(UpdateService.compareVersions('2.0.3-beta-one', '2.0.3-beta-two'), lessThan(0));
    });

    test('invalid versions do not compare as newer', () {
      expect(UpdateService.compareVersions('latest', '2.0.3'), 0);
      expect(UpdateService.compareVersions('2.x.3', '2.0.3'), 0);
    });
  });

  group('update decision (mirrors checkForUpdate logic)', () {
    bool hasUpdate(String latestTag, String installed) {
      final latest = UpdateService.normalizeVersion(latestTag);
      final current = UpdateService.normalizeVersion(installed);
      return latest.isNotEmpty &&
          current.isNotEmpty &&
          UpdateService.compareVersions(latest, current) > 0;
    }

    test('older installed version is offered a newer stable release', () {
      expect(hasUpdate('v2.0.3', '2.0.2'), isTrue);
    });

    test('same version does not prompt', () {
      expect(hasUpdate('v2.0.3', '2.0.3'), isFalse);
    });

    test('empty installed version never prompts', () {
      expect(hasUpdate('v2.0.3', ''), isFalse);
    });

    test('stable release is offered over installed prerelease', () {
      expect(hasUpdate('v2.0.3', '2.0.3-beta.1'), isTrue);
    });
  });
}
