# Phase 2 — Calculation Engine Audit

## Changes in this phase

- Added regression tests for arithmetic precedence, division by zero, invalid square-root domains, descriptive statistics, linear regression, future value, loan payments, and invalid input boundaries.
- Corrected the empty-list product to return the multiplicative identity (`1`).
- Corrected Poisson PMF/CDF behavior for a zero event rate.
- Added guards for invalid compounding frequencies, negative durations, and zero-month loan calculations. Invalid scalar finance inputs return `double.nan`; zero/invalid amortization schedules return an empty list.

## Validation status

The source and tests were reviewed statically. Flutter/Dart are not installed in the current environment, so `flutter pub get`, `flutter analyze`, and `flutter test` could not be executed here. Run these commands in a Flutter SDK environment before merging or releasing.

## Scope note

This phase covers selected high-risk edge cases and regression tests. It is not a proof that every scientific, engineering, or financial formula in the app is correct.
