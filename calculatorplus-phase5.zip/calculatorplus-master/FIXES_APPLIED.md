# Calculator Plus — Fixes Applied

This patch addresses the source-audit findings that could be safely corrected without changing the app's feature architecture.

## Changes

- Replaced the Dart-only CI job with Flutter SDK setup, `flutter pub get`, `flutter analyze`, `flutter test`, and an Android release APK build.
- Updated the GitHub Actions workflow to run on pushes and pull requests regardless of whether the default branch is named `main` or `master`.
- Corrected update version comparison to preserve and compare semantic-version prerelease identifiers (for example, `2.0.3-beta.1` is older than `2.0.3`).
- Added validation for parsed GitHub release payloads and accepted APK download URLs only when they use HTTPS.
- Updated update-service tests for prerelease precedence, numeric component comparisons, malformed versions, and version normalization.
- Removed the hard-coded outdated release version and direct APK URL from the README.
- Added development setup instructions and the MIT license file referenced by the README.

## Validation status

The archive and edited files were checked for consistency. Flutter tests, Dart analysis, and an Android release build could not be executed in this environment because neither the Flutter nor Dart CLI is installed. The CI workflow will run these checks in GitHub Actions; review its result before distributing a release APK.

## Release signing note

The existing Android Gradle configuration falls back to debug signing when `android/key.properties` is absent. Do not distribute an APK built through that fallback as a production release. Configure a private release keystore before publishing a production APK.
