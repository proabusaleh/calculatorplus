import java.util.Properties

plugins {
    id("com.android.application")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(keystorePropertiesFile.inputStream())
}

android {
    namespace = "com.calculatorpluspro.app"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.calculatorpluspro.app"
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String?
            keyPassword = keystoreProperties["keyPassword"] as String?
            storeFile = keystoreProperties["storeFile"]?.let { file(it as String) }
            storePassword = keystoreProperties["storePassword"] as String?
        }
    }

    buildTypes {
        release {
            // Fail closed for production: never publish a debug-signed APK as a
            // release. CI may explicitly opt in to a debug-signed smoke build
            // with -PallowDebugReleaseSigning=true; the release workflow must
            // provide key.properties and must not set that property.
            val allowDebugReleaseSigning =
                project.findProperty("allowDebugReleaseSigning")?.toString() == "true"
            if (keystorePropertiesFile.exists()) {
                val requiredSigningProperties = listOf(
                    "keyAlias", "keyPassword", "storeFile", "storePassword"
                )
                val missingSigningProperties = requiredSigningProperties.filter {
                    keystoreProperties.getProperty(it).isNullOrBlank()
                }
                if (missingSigningProperties.isNotEmpty()) {
                    throw GradleException(
                        "android/key.properties is missing required values: " +
                            missingSigningProperties.joinToString(", ")
                    )
                }
                val configuredStoreFile = file(keystoreProperties.getProperty("storeFile"))
                if (!configuredStoreFile.isFile) {
                    throw GradleException(
                        "Android release keystore was not found at: $configuredStoreFile"
                    )
                }
                signingConfig = signingConfigs.getByName("release")
            } else if (allowDebugReleaseSigning) {
                signingConfig = signingConfigs.getByName("debug")
            } else {
                throw GradleException(
                    "Release signing is not configured. Create android/key.properties " +
                        "and configure a production keystore. Debug signing is allowed " +
                        "only for CI smoke builds with -PallowDebugReleaseSigning=true."
                )
            }
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
