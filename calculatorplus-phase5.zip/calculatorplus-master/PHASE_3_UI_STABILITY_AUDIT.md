# Phase 3 — UI and App Stability

## Changes made

- Hardened persisted display preferences against invalid enum indexes, extreme/non-finite font scales, blank font names, and out-of-range decimal precision.
- Prevented invalid button reorder indexes from throwing and normalized empty profile names.
- Ensured a profile switch starts from safe default display preferences and button layout when that profile has no saved values, instead of inheriting another profile's values.
- Validated saved active profile IDs and fall back to `default` when the stored ID no longer exists.
- Made calculator history loading recover valid records individually when another saved record is corrupt, cap loaded history to the configured limit, and notify listening UI after asynchronous loading finishes.
- Made memory slots and named-variable loading recover from individual malformed records instead of discarding the whole collection.
- Added bounds checking for persisted theme indexes and safe notification behavior after async loads.
- Added `test/phase3_stability_test.dart` for preference recovery and history recovery/notification.

## Validation status

The archive has been inspected and source-level edits have been applied. Flutter and Dart CLIs are not installed in the current environment, so `flutter analyze`, `flutter test`, and a release build could not be executed here. Run these in a Flutter SDK environment before treating the changes as build-verified.

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```
